function Y = fromIndex(Yext, values)
% [Y] = fromIndex(Y2 ,values) : convert index-valued Y into discrete representation specified by "values"

Y = values(Y);


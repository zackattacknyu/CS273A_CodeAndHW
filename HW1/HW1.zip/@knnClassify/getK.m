function K=getK(obj)
% K=getK(obj) : get current parameter K value
  K=obj.K;


function obj = setWeights(obj,wts)
% learner = setWeights(learner,wts) : set the d+1 weights of the linear regression

obj.theta = wts;

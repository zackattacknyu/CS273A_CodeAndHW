function obj = setProbs(obj,p)
% gbc = setProbs(gbc, p) : set the covariances of the classifier

obj.probs = p; 


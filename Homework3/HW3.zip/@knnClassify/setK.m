function obj=setK(obj, K)
% set parameter K if desired
  obj.K = K;


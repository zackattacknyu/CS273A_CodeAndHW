function c = getCovars(obj)
% c = getCovars(gbc) : access the covariances of the classifier

c = obj.covars;


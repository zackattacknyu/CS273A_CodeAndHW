function p = getProbs(obj)
% p = getProbs(gbc) : access the covariances of the classifier

p = obj.probs;


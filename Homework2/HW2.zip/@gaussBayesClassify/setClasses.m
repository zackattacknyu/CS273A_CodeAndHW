function obj=setClasses(obj,c)
% obj=setClasses(obj,classes) : set the list of class IDs associated with this classifier
%   classes should be a column vector of IDs

obj.classes = c;

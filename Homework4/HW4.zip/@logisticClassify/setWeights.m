function obj = setWeights(obj,wts)
% obj = setWeights(obj,wts) : set the (c-1)x(d+1) weights of the linear classifier

obj.wts = wts;
